﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace etterem.proj
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        string paswd = "1234";
        string f_nev = "user";



        public void regisztracio_Click(object sender, RoutedEventArgs e)
        {
            regisztracio ablak2 = new regisztracio();
            ablak2.Show();
            Close();
        }

        private void login_Click(object sender, RoutedEventArgs e)
        {
            
            if (PasswordTextBox.Password == "")
            {

                MessageBox.Show("Hiányzó jelszó");
            }
            else
            {
                PasswordTextBox.Focus();
                if (PasswordTextBox.Password == paswd || f_nev == UsernameTextBox.Text) ;
                fooldal fooldal1 = new fooldal();
                fooldal1.Show();
                Close();
                MessageBox.Show("sikeres bejelentkezés");
                

            }
            
        }
    }
}
